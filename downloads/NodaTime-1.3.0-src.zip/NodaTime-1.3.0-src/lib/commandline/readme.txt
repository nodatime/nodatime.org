The Command Line Parser Library is hosted at
https://github.com/gsscoder/commandline

We build the source files into ZoneInfoCompiler, to avoid requiring a
strongly-named copy of the assembler. Please see the LICENSE file
for further information. We don't anticipate any need to keep this
library particularly up-to-date, and it's not currently included in the
binaries distributed with Noda Time.