This directory contains XML files from previous versions of Noda Time,
used to determine when particular members are introduced. These are the public
XML files, which don't include internal members or remarks.

The filenames are in the slightly unusual form of having the version number
last (after the normal ".xml" extension) as that makes them easier to process.