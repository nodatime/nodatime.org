// Copyright 2011 The Noda Time Authors. All rights reserved.
// Use of this source code is governed by the Apache License 2.0,
// as found in the LICENSE.txt file.

using System.Runtime.CompilerServices;

namespace NodaTime.Fields
{
    /// <summary>
    /// <para>
    /// The NodaTime.Fields namespace contains types related to individual period fields.
    /// All types within this namespace are internal.
    /// </para>
    /// </summary>
    [CompilerGenerated]
    internal static class NamespaceDoc
    {
        // No actual code here - it's just for the sake of documenting the namespace.
    }
}
