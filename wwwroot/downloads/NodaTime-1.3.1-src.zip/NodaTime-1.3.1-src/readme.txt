Noda Time is a port of the Joda Time project to .NET.

Project web site:   http://nodatime.org
Group/mailing list: http://groups.google.com/group/noda-time

Project source and issue site:
                    http://code.google.com/p/noda-time/
