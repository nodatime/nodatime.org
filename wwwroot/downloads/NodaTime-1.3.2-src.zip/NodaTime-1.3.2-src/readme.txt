Noda Time is a better .NET date and time API.

Project web site:   http://nodatime.org
Group/mailing list: http://groups.google.com/group/noda-time

Project source and issue site: https://github.com/nodatime/nodatime
